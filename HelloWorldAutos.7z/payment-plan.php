<!doctype html>

<!-- Web page "Hello World Autos"       -->
<!-- Created by Harrison Kong           -->
<!-- Copyright (C) Coursera 2021        -->

<html lang="en">

<head>

<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
<meta http-equiv=“Pragma” content=”no-cache”>
<meta http-equiv=“Expires” content=”-1″>
<meta http-equiv=“CACHE-CONTROL” content=”NO-CACHE”>
<!-- CSS Stylesheets -->
<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/css/bootstrap.min.css" integrity="sha384-9aIt2nRpC12Uk9gS9baDl411NQApFmC26EwAOH8WgZl5MYYxFfc+NcPb1dKGj7Sk" crossorigin="anonymous">
<link rel="stylesheet" href="css/payment-plan.css">

<script src="https://cdnjs.cloudflare.com/ajax/libs/jspdf/1.3.5/jspdf.debug.js"></script>



<?php include "utilities.php" ?>

<title>Hello World Autos</title>   

</head>

<body>

    <h1>Your Personalised Payment Plan</h1>

    <div class="content-area">
        <img id="vehicle-image" class="hero" src="images/<?php echo $_POST['image'] ?>" alt="vehicle image" />
        <p id="vehicle-make" class="vehicle-make"><?php echo $_POST['make'] ?></p>
        <p id="vehicle-model" class="vehicle-model"><?php echo $_POST['model'] ?></p>
        <hr class="vehicle-hr">
        <p id="vehicle-price" class="vehicle-price">$<?php echo number_format($_POST['price'], 2) ?></p>
        <p><span class="data-label">Repayment duration: </span><span id="payment-duration" class="data-item"><?php echo $_POST['repayment-duration'] ?> months</span></p>
        <p><span class="data-label">Interest rate: </span><span id="interest-rate" class="data-item"><?php echo $_POST['interest-rate'] ?>% APR</span></p>
        <p><span class="data-label">Total payment: </span><span id="total-payment" class="data-item">$<?php echo number_format(calculateTotalPayment($_POST['price'], $_POST['repayment-duration'], $_POST['interest-rate']), 2) ?></span></p>
        <p><span class="data-label">Total interest: </span><span id="total-interest" class="data-item">$<?php echo number_format(calculateTotalInterest($_POST['price'], $_POST['repayment-duration'], $_POST['interest-rate']), 2) ?></span></p>
        <hr class="short-line">
        <p><span class="data-label">Monthly payment: </span><span id="monthly-payment" class="focal-point">$<?php echo number_format(calculateMonthlyPayment($_POST['price'], $_POST['repayment-duration'], $_POST['interest-rate']), 2) ?></span></p>
        <p><button onclick="generatePDF()">Export...</button></p>
        <br /><br />
    </div>

<script src="js/pdf.js"></script>

</body>

<footer>
    <?php include "footer.php" ?>
</footer>

</html>