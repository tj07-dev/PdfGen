function generatePDF() {

    // task 2 - initialise the document

    // default size is A4, default orientation is portrait
    var pdf = new jsPDF();
    // if you want to use US letter as the page size, for example:
    // var pdf = new jsPDF({ format: "letter" });

    // task 2 - get document properties

    var pageWidth = pdf.internal.pageSize.width;
    var pageHeight = pdf.internal.pageSize.height;

    console.log("page width = " + pageWidth);
    console.log("page height = " + pageHeight);

    // task 2 - set document properties

    pdf.setProperties({
        title: 'Your Personalised Payment Plan',
        subject: 'payments',
        author: 'Hello World Autos',
        keywords: 'autos, payments, sales',
        creator: 'Hello World Autos website',
    });

    // task 3 - text and fonts

    pdf.setFont("arial");  // font weight does not work
    
    // pdf.setFontType("bolditalic");   // note that this is if you want both bold and italic
    pdf.setFontType("bold");

    pdf.setFontSize(30);
    pdf.setTextColor(0, 0, 139);
    pdf.text(pageWidth / 2, 15, "Your Personalised Payment Plan", "center");

    // leave it bold
    // leave it blue
    pdf.setFontSize(30);
    var vehicleMake = document.getElementById("vehicle-make").innerHTML;
    var vehicleModel = document.getElementById("vehicle-model").innerHTML;

    pdf.text(pageWidth / 2 - 15, 160, vehicleMake + " " + vehicleModel, "center");

    var vehiclePrice = document.getElementById("vehicle-price").innerHTML;

    pdf.setTextColor(240, 0, 0);
    pdf.setFontSize(25);

    pdf.text(pageWidth / 2 + 20, 170, vehiclePrice, "center");

    // task 4 - display the rest of the payment details

    var paymentDuration = document.getElementById("payment-duration").innerHTML;
    var interestRate = document.getElementById("interest-rate").innerHTML;

    pdf.setTextColor(0, 0, 0);
    pdf.setFontSize(16);
    pdf.text(pageWidth / 2, 190, interestRate + " for " + paymentDuration, "center");

    var totalPayment = document.getElementById("total-payment").innerHTML;

    pdf.text(pageWidth / 2, 210, "Total Payment: " + totalPayment, "center");

    var totalInterest = document.getElementById("total-interest").innerHTML;

    pdf.text(pageWidth / 2, 220, "Total Interest: " + totalInterest, "center");

    pdf.setTextColor(0, 128, 0);
    pdf.setFontSize(22);

    var monthlyPayment = document.getElementById("monthly-payment").innerHTML;
    pdf.text(pageWidth / 2, 245, "Monthly Payment: " + monthlyPayment, "center");

    // task 5 - image

    var vehicleImage = document.getElementById("vehicle-image");
    var aspectRatio = vehicleImage.width / vehicleImage.height;
    var scaledWidth = pageWidth * 0.8;

    pdf.addImage(vehicleImage, "JPEG", (pageWidth - scaledWidth) / 2, 27, scaledWidth, scaledWidth / aspectRatio);

    // task 6 - lines

    var lineWidth = pageWidth * 0.9;
    pdf.line((pageWidth - lineWidth)/2, 175, lineWidth + (pageWidth - lineWidth)/2, 175, "S");

    pdf.setDrawColor(0, 128, 0);
    pdf.setLineWidth(2.0);
    pdf.setLineCap("round");

    var lineWidth2 = pageWidth * 0.6;
    pdf.line((pageWidth - lineWidth2)/2, 230, lineWidth2 + (pageWidth - lineWidth2)/2, 230, "S");

    // task 7 - draw graphics

    pdf.setLineWidth(1.0);
    pdf.setDrawColor(255, 0, 0);
    pdf.rect(35, pageHeight - 25, 15, 15);

    pdf.setDrawColor(0, 0, 255);
    pdf.setFillColor(0, 0, 255);    
    pdf.circle(80, pageHeight - 20, 7, "FD");

    pdf.setDrawColor(255, 0, 255);
    pdf.setFillColor(255, 255, 0);
    pdf.triangle(115, pageHeight - 20, 120, pageHeight - 10, 130, pageHeight - 10, "FD");

    pdf.setDrawColor(0, 128, 0);
    pdf.setFillColor(255, 128, 0)
    pdf.ellipse(165, pageHeight - 25, 10, 5, "FD");

    // task 2 - launch the preview

    // if we want to download directly:
    // pdf.save("hello-world.pdf");

    var output = pdf.output("bloburl", {filename: "plan.pdf"});
    console.log(output);
    window.open(output, "_blank");
}

// generatePDF();
